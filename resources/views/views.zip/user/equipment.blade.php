@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-800">Available Sports Equipment</h1>
        <a href="{{ route('borrow.create') }}" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            <i class="fas fa-plus mr-2"></i>Borrow Equipment
        </a>
    </div>

    @if(session('success'))
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
        <strong class="font-bold">Success! </strong>
        <span class="block sm:inline">{{ session('success') }}</span>
    </div>
    @endif

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @forelse($equipment as $item)
        <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
            @if($item->item_image)
            <img src="{{ asset('images/' . $item->item_image) }}" alt="{{ $item->item_name }}" class="w-full h-48 object-cover">
            @else
            <div class="bg-gray-200 border-2 border-dashed rounded-xl w-full h-48 flex items-center justify-center">
                <span class="text-gray-500">No Image</span>
            </div>
            @endif
            <div class="p-6">
                <h3 class="text-xl font-semibold text-gray-800 mb-2">{{ $item->item_name }}</h3>
                <div class="flex justify-between items-center mb-4">
                    <span class="px-2 py-1 text-xs font-semibold rounded-full 
                        {{ $item->item_status === 'available' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }}">
                        {{ ucfirst($item->item_status) }}
                    </span>
                    <span class="text-sm font-medium text-gray-700">
                        <i class="fas fa-boxes"></i> {{ $item->item_quantity }} available
                    </span>
                </div>
                <a href="{{ route('borrow.create') }}" class="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded text-center block">
                    <i class="fas fa-hand-pointer mr-2"></i>Borrow
                </a>
            </div>
        </div>
        @empty
        <div class="col-span-3">
            <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 p-8 text-center">
                <h3 class="text-xl font-semibold text-gray-800 mb-2">No Equipment Available</h3>
                <p class="text-gray-600">There is currently no sports equipment available for borrowing.</p>
            </div>
        </div>
        @endforelse
    </div>
</div>
@endsection