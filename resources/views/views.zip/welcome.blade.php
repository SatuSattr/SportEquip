@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="text-center mb-12">
        <h1 class="text-4xl font-bold text-gray-800 mb-4">Sports Equipment Inventory System</h1>
        <p class="text-lg text-gray-600 max-w-2xl mx-auto">
            Manage your sports equipment inventory efficiently. Borrow equipment for your activities or manage the inventory as an administrator.
        </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
            <div class="bg-gray-100 p-6">
                <h2 class="text-2xl font-semibold text-gray-800 mb-2">For Users</h2>
                <p class="text-gray-600 mb-4">Browse and borrow available sports equipment.</p>
            </div>
            <div class="p-6">
                <a href="{{ route('equipment.list') }}" class="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded text-center block mb-4">
                    <i class="fas fa-dumbbell mr-2"></i>Browse Equipment
                </a>
                <a href="{{ route('borrow.create') }}" class="w-full bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded text-center block">
                    <i class="fas fa-hand-pointer mr-2"></i>Borrow Equipment
                </a>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
            <div class="bg-gray-100 p-6">
                <h2 class="text-2xl font-semibold text-gray-800 mb-2">For Administrators</h2>
                <p class="text-gray-600 mb-4">Manage equipment inventory and borrowing requests.</p>
            </div>
            <div class="p-6">
                @if (Route::has('login'))
                    @auth
                        <a href="{{ url('/dashboard') }}" class="w-full bg-indigo-500 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded text-center block">
                            <i class="fas fa-tachometer-alt mr-2"></i>Admin Dashboard
                        </a>
                    @else
                        <a href="{{ route('login') }}" class="w-full bg-indigo-500 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded text-center block">
                            <i class="fas fa-sign-in-alt mr-2"></i>Admin Login
                        </a>
                    @endauth
                @endif
            </div>
        </div>
    </div>

    <div class="mt-12 text-center">
        <h3 class="text-xl font-semibold text-gray-800 mb-4">How It Works</h3>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div class="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div class="text-blue-500 text-3xl mb-3">
                    <i class="fas fa-search"></i>
                </div>
                <h4 class="text-lg font-medium text-gray-800 mb-2">Browse Equipment</h4>
                <p class="text-gray-600">View all available sports equipment in our inventory.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div class="text-green-500 text-3xl mb-3">
                    <i class="fas fa-calendar-plus"></i>
                </div>
                <h4 class="text-lg font-medium text-gray-800 mb-2">Submit Request</h4>
                <p class="text-gray-600">Fill out a simple form to request equipment borrowing.</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                <div class="text-indigo-500 text-3xl mb-3">
                    <i class="fas fa-clipboard-check"></i>
                </div>
                <h4 class="text-lg font-medium text-gray-800 mb-2">Admin Approval</h4>
                <p class="text-gray-600">Administrators review and approve borrowing requests.</p>
            </div>
        </div>
    </div>
</div>
@endsection